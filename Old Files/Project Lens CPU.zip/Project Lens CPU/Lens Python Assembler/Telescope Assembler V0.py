"""
This is an assembler for the Telescope computer system.
Usage: TelescopeAssemblerV0.py INPUT_FILE.tas
Writes assembled code to INPUT_FILE.to

When ran outside of the command line, this assembler takes the name of your file as an input, and looks for its
.tas file in the current directory. It then scans through it, does some basic error detection, then spits out a
.to machine code file for you to load into the computer.
"""

# Usually I write the assemblers for my computers ~in~ the computers. However, this time I found translation to be
# way more difficult than my other ISA's, since this one uses 5-bit operands in a lot of places and the instruction
# codes themselves are within a 6-bit range. So, I immediately wrote this right after the very first test program.
# That test program, by the way, is the "Does It Work Test"

# Also, I eventually went back and redid the ISA so that manual translation was more easy.


from sys import argv  # Importing sys for argument inputs


# ---------------------Important assembling symbols/mnemonics SHOULD BE LOWERCASE!!!!----------------------------

# By default, variables will be defined as static and all references to it will return its assigned value
# However, if you want to manipulate the variable and/pr put it in memory, define a pointer to it using def*
# All references to these dynamic variables will return their address, not their defined value.
# Format: def VariableName value (where value can be 0b011011 binary, 0x0ff hexadecimal, or 2125 decimal)
CONSTANT_DECLARATION = "def"
VARIABLE_DECLARATION = "def*"

# Arrays are used a bit oddly compared to other assemblers, as you can't index them like normal. Instead, you need to:
# 1. Load the given offset in a temp register, and 2. Do LOD/STR op0, temp, ArrayLabel
# Format: arr val1, val2, val3, ...
ARRAY_DECLARATION = "arr"

# Labelling is done like ":ThisIsALabel:" and can be referenced just like variables
LABEL_PUNCTUATION = ":"

# Users can make comments in files by doing //This is a comment
COMMENT_SPACER = "//"

# File constants
OUTPUT_SUFFIX = ".to"
ASSEMBLY_SUFFIX = ".tas"
FILE_HEADER = "v2.0 raw"

# Indexes in the InstLUT for better code readability
WORDS = 2
OPERANDS = 1
CODE = 0

# For Logisim's memory loading
WriteMod8 = 0
WORDS_PER_LINE = 8

# ISA constants
OP_BITS = 5
OP1_MASK = 0x001F

# Declaration of file related variables
FileName = ""
InputFileName = ""
OutputFileName = ""
OutputStrings = []

# Lookup tables/lists that need to be populated
LabelLUT = {}
ConstantsLUT = {}
DefinedDataList = []

# For customized output
IsTerminal = False


# -----------------------------------Pre-defined Lookup Tables----------------------------------------

# Contains the identifying bit pattern for each instruction
# Note that instructions have been added which are not part of the ISA.
# These new instructions are logical abstractions of specific instructions & operands
InstructionLUT = {
    # Note, [opX] means that operand X is a number/reference
    # INST: (CODE, NumOp, NumWord)

    # ISA Instructions
    "alu": (0x8000, 3, 1),  # Op1 <Op0> Op2 -> Op1. Some ALU ops deviate from this slightly. Flags are always set
    "str": (0x7000, 3, 2),  # Copy data from op0 to address op1 + [op2]
    "lod": (0x6000, 3, 2),  # Copy data to op0 from address op1 + [op2]
    "jif": (0x5000, 2, 2),  # Jump to [op1] if op0 is true
    "jal": (0x4000, 1, 2),  # Unconditional jump to [op0] and write PC to RA
    "mov": (0x3000, 2, 1),  # Copy data to op0 from op1
    "ldi": (0x2000, 2, 2),  # Copy the value of [op1] into op0
    "sys": (0x1100, 0, 1),  # Triggers a SYS exception
    "rsm": (0x1000, 0, 1),  # Pops the current User/ExEn/LOen stack, and jumps to EPC
    "nop": (0x0100, 0, 1),  # Does nothing (meant for use as part of a bootloader device for pausing the CPU)
    "hlt": (0x0000, 0, 1),  # Stops the computer. Must be handled outside of the CPU

    # New Instructions
    "jmp": (0x5800, 1, 2),  # Unconditional jump to [op0]
    "mwt": (0x7010, 2, 2),  # Copy data from op0 to address [op1]
    "mrd": (0x6010, 2, 2),  # Copy data from address [op1] to op0
    "ret": (0x3274, 0, 1),  # Jump to RA
    "inc": (0xA801, 1, 1),  # Add 1 to op0
    "dec": (0xB401, 1, 1),  # Subtract 1 from op0
    "pas": (0x8000, 1, 1),  # Pass op0 through the ALU, setting flags
    "cmp": (0xB800, 2, 1)   # Does op1 PSUB op2
}

# Contains the internal addresses for each register
RegisterLUT = {

    # General Purpose Registers
    "reg0": 0, "reg1": 1, "reg2": 2,  "reg3": 3,  "reg4": 4,  "reg5": 5,  "reg6": 6,  "reg7": 7,
    "reg8": 8, "reg9": 9, "rega": 10, "regb": 11, "regc": 12, "regd": 13, "rege": 14, "regf": 15,

    # Special Registers
    "zero": 16,
    "iop": 17,
    "io": 18,
    "pc": 19,
    "ra": 20,
    "sp": 21,
    "null": 31,

    # Special Write Protected Registers
    "flag": 22,
    "ctd": 23,
    "ctu": 24,
    "bot": 25,
    "hi": 26,

    # Special Read/Write Protected Registers
    "lo": 27,   # Floor of the current process in memory. All addressing is relative to this register.
    "eca": 28,  # When an exception occurs due to OOB, it's stored here (only most of the time as of 11-9-21)
    "epc": 29,  # The address to return to after an exception, assuming you wish to return to it.
    "exa": 30   # The address jumped to when an exception occurs. There should be an exception handler here if
                # exceptions are enabled.
}

# Contains the OpCode for each ALU operation
# Note that some new mnemonics have been added. New ones should be added right after their original counterpart
# Also, you can use variables with immediate operations, but only the lower 5 bits will count
ALUOpLUT = {

    # Logical Operations
    "pass": 0,  # Op2
    "not": 1,   # logical NOT of Op2
    "and": 2,   # logical AND of Op1 and Op2
    "nand": 3,  # ... and so on
    "or": 4,
    "nor": 5,
    "xor": 6,
    "xnor": 7,

    # Arithmetic Operations
    "sum": 8,    # Op1+Op2
    "add": 8,
    "sumc": 9,   # Op1+Op2+Carry
    "addc": 9,
    "adc": 9,
    "sumi": 10,  # Op1+[Op2]
    "addi": 10,
    "adi": 10,
    "sub": 11,   # Op1-Op2
    "subb": 12,  # Op1-Op2 with carry as borrow
    "subi": 13,  # Op1-[Op2]
    "sbi": 13,
    "psub": 14,  # Op1-Op2, but DOES NOT WRITE TO Op1
    "mult": 15,  # Op1*Op2
    "mulu": 16,  # Op1*Op2, returns the upper 2 bytes
    "udiv": 17,  # Unsigned Op1/Op2
    "mod": 18,   # Op1 mod Op2
    "lsb": 19,   # Op1 << Op2
    "lsbi": 20,  # Op1 << [Op2]
    "rsb": 21,   # Logical Op1 >> Op2
    "rsbi": 22,  # Logical Op1 >> [Op2]
    "rsa": 23,   # Arithmatic Op1 >> Op2
    "rsai": 24,  # Arithmatic Op1 >> Op2

    # Special Operations
    "ctb": 25,   # Returns the number of on bits in Op2
    "totl": 25,
    "count": 25,
    "rand": 26,  # Returns a random number
    "atn": 27,   # Treats the value in Op2 as a 2-digit ASCII (8-bit) hex number, returns its corresponding value
    "ntal": 28,  # Returns the 2-digit ASCII number for the lower byte of Op1
    "ntau": 29,  # Like ntal, but for the upper byte
    "enc": 30,   # Runs Op2 through a priority encoder
    "dcd": 31    # Runs Op2 through a decoder
}

# Contains the number associated with each flag visible to JIF
ConditionLUT = {
    "zero": 0,
    "z": 0,
    "eqz": 0,
    "equal": 0,
    "eq": 0,
    "carry": 1,
    "c": 1,
    "neg": 2,
    "sign": 2,
    "lz": 2,
    "over": 3,
    "o": 3,
    "iord": 4,
    "iowt": 5,
    "false": 6,
    "true": 7,
    "!zero": 8,
    "!equal": 8,
    "neq": 8,
    "nez": 8,
    "!z": 8,
    "!carry": 9,
    "!c": 9,
    "!neg": 10,
    "!sign": 10,
    "pos": 10,
    "gz": 10,
    "!over": 11,
    "!o": 11,
    "!iord": 12,
    "!iowt": 13,
    "!false": 14,
    "!true": 15
}


# ------------------------------------------The Assembler------------------------------------------

def append_file_header():
    """Use appending the file header as a test to see if the file exists"""
    try:
        open(InputFileName, "r")
    except FileNotFoundError:
        error_msg("Proper assembly file not found.", "", "Looking for file: " + InputFileName)
    OutputStrings.append(FILE_HEADER + "\n")


def append_output(string):
    """Specialized append function for Logisim memory"""
    global WriteMod8
    hexString = hex(string)

    # Write everything but the 0x
    OutputStrings.append(hexString[2:] + " ")
    WriteMod8 += 1

    # Every 8 go to a new line
    if WriteMod8 >= WORDS_PER_LINE:
        WriteMod8 = 0
        OutputStrings.append("\n")


def error_msg(msg, lineNo, line, extra=""):
    """Custom error message, then terminate. Makes sure normal users see the message."""
    print("")
    print("*******ERROR********")
    print("")
    print(str(msg))
    print("Line " + str(lineNo) + " - '" + str(line) + "'")
    print(str(extra))

    if not IsTerminal:
        print("Press enter to stop the program...")

    exit(1)


def get_value_of(string, lineNo):
    """
    Returns the value of the given data/address operand of an instruction.
    Line number is an argument for debugging.
    """
    value = 0

    # If the input is a constant variable
    if string in ConstantsLUT:
        return ConstantsLUT[string]
    # If the input is a label/dynamic variable
    if string in LabelLUT:
        return LabelLUT[string]
    # If none of the above, check if it's a number in 3 bases
    try:
        value = int(string, base=10)
    except ValueError:
        try:
            value = int(string, base=2)
        except ValueError:
            try:
                value = int(string, base=16)
            except ValueError:
                error_msg("Bad value in internal get_value_of(). Could be improper syntax.", lineNo, str(value))
    if value < 0:
        value = value & 0xffff
    return value


def clean_line(line):
    """Returns a cleaned version of the line"""
    trueLine = (line.split(COMMENT_SPACER)[0]).lower()
    trueLine = (trueLine.strip()).replace(",", "")
    return trueLine


def passthrough_build_tables():
    """Does 1 pass through the file to populate the label table and the variable table"""
    input = open(InputFileName)
    lineNo = 1
    programCounter = 0
    dataPointersList = []

    for line in input:
        cleanLine = clean_line(line)

        # Make sure what's left isn't empty
        if not (cleanLine.isspace() or cleanLine == ""):
            cleanLineArgs = cleanLine.split()
            arg0 = cleanLineArgs[0]

            # Line is a label (doubly encased in the punctuation for the Notepad++ UDL definer)
            if arg0[-1] == arg0[0] == LABEL_PUNCTUATION:

                # Make sure its formatted somewhat properly
                if len(cleanLineArgs) != 1:
                    error_msg("Improper label definition.", lineNo, line)

                # Add it to the label table
                label = cleanLine[1:-1]
                LabelLUT[label] = programCounter

            # Line is a variable definition
            elif arg0 == VARIABLE_DECLARATION or arg0 == CONSTANT_DECLARATION:
                arg1 = cleanLineArgs[1]

                # Check to make sure it has the right number of arguments
                if len(cleanLineArgs) != 3:
                    error_msg("Improper variable decl. length.", lineNo, line)

                # Check to make sure this is not a repeat
                if arg1 in LabelLUT or arg1 in ConstantsLUT:
                    error_msg("Variable name already defined elsewhere.", lineNo, line)

                # Try to get the value for the definition
                value = get_value_of(cleanLineArgs[2], lineNo)

                # Add it to the corresponding table
                if arg0 == VARIABLE_DECLARATION:
                    LabelLUT[arg1] = len(DefinedDataList)
                    dataPointersList.append(arg1)
                    DefinedDataList.append(value)
                else:
                    ConstantsLUT[arg1] = value

            # Line is an array declaration
            elif arg0 == ARRAY_DECLARATION:
                arg1 = cleanLineArgs[1]

                # Check for problems
                if not len(cleanLineArgs) > 2:
                    error_msg("Arrays need a name and at least one element", lineNo, line)
                if arg1 in LabelLUT or arg1 in ConstantsLUT:
                    error_msg("Array's label is already defined elsewhere", lineNo, line)

                LabelLUT[arg1] = len(DefinedDataList)
                dataPointersList.append(arg1)
                for arg in cleanLineArgs[2:]:
                    DefinedDataList.append(get_value_of(arg, lineNo))

            # Line is a normal line of code
            elif arg0 in InstructionLUT:
                programCounter += 1
                # Check if it's two lines in machine code
                if InstructionLUT[arg0][WORDS] == 2:
                    programCounter += 1

            # We have no idea what this line is
            else:
                error_msg("Unkown line of assembly.", lineNo, line)
        lineNo += 1

    # Adjust the pointers to dynamic variables now that we know where to put them
    for label in dataPointersList:
        LabelLUT[label] += programCounter

    input.close()


def passthrough_translate():
    """Does pass 2 to translate the mnemonics to machine code, now that it has the labels & variables"""
    input = open(InputFileName, "r")
    programCounter = 0
    lineNo = 0

    for line in input:

        # Clean up the input
        cleanLine = clean_line(line)

        # Ignore empty lines. Note: this must occur before the coming if statements, because if the line is empty, the
        # following checks will cause an indexing exception.
        if not (cleanLine.isspace() or cleanLine == ""):

            # Split the line into its parts
            args = cleanLine.split()
            arg0 = args[0]

            isLabel = (arg0[0] == arg0[-1] == LABEL_PUNCTUATION)
            isVar = (arg0 == VARIABLE_DECLARATION)
            isArray = (arg0 == ARRAY_DECLARATION)
            isConst = (arg0 == CONSTANT_DECLARATION)
            if not (isLabel or isVar or isConst or isArray):

                # Check if we actually know what instruction it is
                if not (arg0 in InstructionLUT):
                    error_msg("Unknown instruction.", lineNo, line, "Instruction: " + arg0)
                # Check if the right number of arguments were passed
                elif len(args) != (InstructionLUT[arg0][OPERANDS] + 1):
                    error_msg("Wrong number of arguments.", lineNo, line)

                # Check what type of instruction it is
                instCode = InstructionLUT[arg0][CODE]
                words = InstructionLUT[arg0][WORDS]
                match arg0:
                    case "sys" | "rsm" | "hlt" | "nop" | "ret":
                        append_output(instCode)

                    case "dec" | "inc":
                        machineCode = instCode | (RegisterLUT[args[1]] << OP_BITS)
                        append_output(machineCode)

                    case "pas":
                        machineCode = instCode | (RegisterLUT[args[1]] << OP_BITS) | RegisterLUT[args[1]]
                        append_output(machineCode)

                    case "mov" | "cmp":
                        machineCode = instCode | (RegisterLUT[args[1]] << OP_BITS) | RegisterLUT[args[2]]
                        append_output(machineCode)

                    case "ldi":
                        machineCode = instCode | (RegisterLUT[args[1]] << OP_BITS)
                        append_output(machineCode)
                        append_output(get_value_of(args[2], lineNo))

                    case "lod" | "str":
                        machineCode = instCode | (RegisterLUT[args[1]] << OP_BITS) | RegisterLUT[args[2]]
                        append_output(machineCode)
                        append_output(get_value_of(args[3], lineNo))

                    case "mrd" | "mwt":
                        machineCode = instCode | (RegisterLUT[args[1]] << OP_BITS)
                        append_output(machineCode)
                        append_output(get_value_of(args[2], lineNo))

                    case "jif":
                        machineCode = instCode | (ConditionLUT[args[1]] << 8)
                        append_output(machineCode)
                        append_output(get_value_of(args[2], lineNo))

                    case "jal" | "jmp":
                        append_output(instCode)
                        append_output(get_value_of(args[1], lineNo))

                    case "alu":
                        # If both operands are registers
                        if args[3] in RegisterLUT:
                            machineCode = instCode | (ALUOpLUT[args[1]] << (2 * OP_BITS)) | \
                                          (RegisterLUT[args[2]] << OP_BITS) | RegisterLUT[args[3]]
                            append_output(machineCode)

                        # If the second is a value
                        else:
                            value = get_value_of(args[3], lineNo) & OP1_MASK  # Only 5 bits can fit in the operand
                            machineCode = instCode | (ALUOpLUT[args[1]] << (2 * OP_BITS)) | \
                                          (RegisterLUT[args[2]] << OP_BITS) | value
                            append_output(machineCode)
                    case _:
                        error_msg("Unknown instruction.", lineNo, line)
                programCounter += words

        lineNo += 1

    input.close()


def append_defined_values():
    """Adds the dynamic variable & array values to their proper locations."""
    for variable in DefinedDataList:
        append_output(variable)


def write_to_output():
    """Finalize all writes and send them to the output file."""
    output = open(OutputFileName, "w")
    output.writelines(OutputStrings)
    output.close()


def main():
    """The main function of the assembler."""
    global FileName, InputFileName, OutputFileName, IsTerminal

    # For Notepad++ UDL group defining. Replace the LUT for each group
    # entries = ""
    # for entry in ConditionLUT:
    #     entries += entry + " "
    # print(entries)
    # exit(1)

    # Assume the person just runs the .py script
    if len(argv) == 1:
        FileName = input("Enter the file name to assemble (without the file extension): ")
        InputFileName = FileName + ASSEMBLY_SUFFIX
        OutputFileName = FileName + OUTPUT_SUFFIX

    # Assuming someone's trying to use it via console
    elif len(argv) != 2:
        raise TypeError(
            "Wrong number of arguments passed to assembler.\nCorrect Form: TelescopeAssemblerV0.py INPUT_FILE")

    # Assuming someone's using it properly
    elif argv[1][-4:] == ASSEMBLY_SUFFIX:
        InputFileName = argv[1]
        OutputFileName = argv[1][:-4] + OUTPUT_SUFFIX
        IsTerminal = True

    # Someone gave the wrong file type
    else:
        raise TypeError("Input file must be a .tas file")

    print("Looking for file: " + InputFileName)
    append_file_header()

    print("Passthrough 1: Building Tables...")
    passthrough_build_tables()

    print("Passthrough 2: Assembling...")
    passthrough_translate()

    print("Writing dynamic variables...")
    append_defined_values()

    print("Writing to file...")
    write_to_output()

    print("Input file '" + InputFileName + "' successfully assembled to file '" + OutputFileName + "'")
    if not IsTerminal:
        input("Press enter to close the program...")


main()
